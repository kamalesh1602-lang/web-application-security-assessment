from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle
from reportlab.lib.styles import getSampleStyleSheet
def generate_pdf(findings,output="reports/security-assessment.pdf"):
    Path(output).parent.mkdir(parents=True,exist_ok=True)
    styles=getSampleStyleSheet()
    story=[Paragraph("Web Application Security Assessment",styles["Title"]),
           Spacer(1,12),Paragraph("Scope: localhost-only, non-invasive checks.",styles["BodyText"]),Spacer(1,12)]
    data=[["ID","Finding","Severity","Result","Evidence"]]
    for f in findings:
        data.append([f.get("id",""),f.get("title",""),f.get("severity",""),
                     f.get("status",""),str(f.get("evidence",""))[:160]])
    t=Table(data,repeatRows=1,colWidths=[55,120,60,60,225])
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#172554")),
        ("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),.4,colors.grey),
        ("VALIGN",(0,0),(-1,-1),"TOP"),("FONTSIZE",(0,0),(-1,-1),7)]))
    story.append(t)
    story.append(Spacer(1,12))
    story.append(Paragraph("A failed configuration check is an indicator, not proof of exploitability. "
                           "Only checks that actually ran are represented.",styles["BodyText"]))
    SimpleDocTemplate(output,pagesize=A4).build(story)
    return output
