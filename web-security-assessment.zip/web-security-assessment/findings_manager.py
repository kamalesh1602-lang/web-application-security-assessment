def summarize(findings):
    result={"PASS":0,"FAIL":0,"REVIEW":0,"NOT TESTED":0}
    for f in findings: result[f.get("status","NOT TESTED")]=result.get(f.get("status","NOT TESTED"),0)+1
    return result
