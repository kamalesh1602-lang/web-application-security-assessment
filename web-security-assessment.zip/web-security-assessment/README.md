# Web Application Security Assessment, Vulnerability Remediation & Retesting Framework

Beginner-friendly defensive security project using Python and Flask. It performs non-invasive checks against localhost only, presents evidence-based findings, and generates a PDF summary.

## Features
- Strict localhost target allowlist.
- HTTPS indicator and HTTP security-header checks.
- Server information disclosure check.
- Synthetic password hashing demonstration.
- Input validation examples and safe event logging.
- Responsive Flask dashboard and PDF report.
- Pytest tests; optional Bandit and pip-audit checks.

## Stack
Python 3, Flask, Requests, Werkzeug, Pytest, ReportLab, Bandit, pip-audit, HTML and CSS.

## Setup — Windows PowerShell
```powershell
py -3 -m venv .venv
.venv\\Scripts\\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000.

## Setup — Kali Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

## Tests and tools
```bash
pytest -v
bandit -r . -x ./.venv
pip-audit -r requirements.txt
```
Run a local assessment from the home page. The PDF is saved in `reports/`.

## Safety
Only localhost, 127.0.0.1, and ::1 are accepted. Do not scan systems without written authorization. No exploitation, password guessing, or aggressive scanning is implemented.

## Interpretation
A missing header is a weakness indicator, not proof of exploitability. A test not run is not a pass. Review dependency advisories against current vendor guidance.

## Limitations
This educational baseline is not production-ready and is not a replacement for a professional security review. It does not perform full penetration testing, TLS certificate analysis, crawling, or exploit validation.

## Author
Kamalesh S. — B.Tech Cybersecurity Student
