from pathlib import Path
import subprocess,sys
def inspect_requirements(path="requirements.txt"):
    p=Path(path)
    return [x.strip() for x in p.read_text().splitlines()
            if x.strip() and not x.lstrip().startswith("#")] if p.exists() else []
def run_pip_audit():
    try:
        p=subprocess.run([sys.executable,"-m","pip_audit","-r","requirements.txt"],
                         capture_output=True,text=True,timeout=60)
        return {"status":"PASS" if p.returncode==0 else "REVIEW","output":p.stdout+p.stderr}
    except (FileNotFoundError,subprocess.TimeoutExpired) as e:
        return {"status":"NOT TESTED","output":type(e).__name__}
