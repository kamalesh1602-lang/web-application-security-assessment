def validate_username(value):
    if not isinstance(value,str): return False,"Username must be text."
    value=value.strip()
    if not 1 <= len(value) <= 32: return False,"Username must contain 1-32 characters."
    if not value.replace("_","").replace("-","").isalnum():
        return False,"Use letters, numbers, underscore, or hyphen."
    return True,"Valid username."
def validate_text(value, limit=200):
    return isinstance(value,str) and 0 < len(value) <= limit
