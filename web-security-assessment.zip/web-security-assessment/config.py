import os
class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "local-dev-only-change-before-deployment")
    ALLOWED_HOSTS = {"localhost", "127.0.0.1", "::1"}
    REQUEST_TIMEOUT = 5
