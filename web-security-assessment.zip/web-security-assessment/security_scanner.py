from urllib.parse import urlparse
import requests
from config import Config

HEADERS = {
 "Content-Security-Policy": ("High", "Define a restrictive content security policy."),
 "X-Frame-Options": ("Medium", "Set DENY or SAMEORIGIN."),
 "X-Content-Type-Options": ("Low", "Set nosniff."),
 "Strict-Transport-Security": ("Medium", "Enable HSTS after HTTPS deployment."),
 "Referrer-Policy": ("Low", "Set a privacy-conscious Referrer-Policy.")
}
def validate_target(url):
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("Enter a valid HTTP or HTTPS URL.")
    if p.hostname.lower() not in Config.ALLOWED_HOSTS:
        raise ValueError("Only localhost targets are allowed.")
    if p.username or p.password:
        raise ValueError("Credentials in URLs are not accepted.")
    return url

def assess_url(url):
    validate_target(url)
    try:
        r = requests.get(url, timeout=Config.REQUEST_TIMEOUT, allow_redirects=False)
    except requests.RequestException as exc:
        return [{"id":"WEB-000","title":"Connection","component":"HTTP","severity":"Info",
                 "status":"NOT TESTED","evidence":type(exc).__name__,
                 "description":"Local service could not be reached.",
                 "remediation":"Start the local app and retry.","retest":"Not performed"}]
    out = [{"id":"WEB-001","title":"HTTPS usage","component":"Transport","severity":"Medium",
            "status":"PASS" if url.startswith("https://") else "FAIL",
            "evidence":"URL scheme: "+urlparse(url).scheme,
            "description":"Checks whether HTTPS is used.",
            "remediation":"Use HTTPS with a valid certificate in deployment.","retest":"Pending"}]
    for h,(sev,fix) in HEADERS.items():
        out.append({"id":"HDR-"+h.upper().replace("-",""),"title":h,
                    "component":"HTTP headers","severity":sev,
                    "status":"PASS" if h in r.headers else "FAIL",
                    "evidence":r.headers.get(h,"Header absent"),
                    "description":"Checks presence of "+h+".","remediation":fix,"retest":"Pending"})
    leaked = [x for x in ("Server","X-Powered-By") if r.headers.get(x)]
    out.append({"id":"INFO-001","title":"Server information disclosure",
                "component":"HTTP headers","severity":"Low",
                "status":"FAIL" if leaked else "PASS",
                "evidence":", ".join(f"{x}: {r.headers[x]}" for x in leaked) or "No common identifying headers",
                "description":"Checks common server-identification headers.",
                "remediation":"Remove unnecessary server-identification headers.",
                "retest":"Pending"})
    return out
