def remediation_for(finding):
    return finding.get("remediation","Review evidence and apply a secure configuration.")
