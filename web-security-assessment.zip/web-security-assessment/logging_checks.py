import logging
from pathlib import Path
def get_logger():
    Path("reports").mkdir(exist_ok=True)
    log=logging.getLogger("security_assessment")
    if not log.handlers:
        h=logging.FileHandler("reports/security-events.log",encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        log.addHandler(h); log.setLevel(logging.INFO); log.propagate=False
    return log
