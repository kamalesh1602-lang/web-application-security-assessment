from flask import Flask,render_template,request,flash
from config import Config
from security_scanner import assess_url
from findings_manager import summarize
from report_generator import generate_pdf
from authentication_checks import hash_password,verify_password
from validation_checks import validate_username
from logging_checks import get_logger

def create_app(test_config=None):
    app=Flask(__name__); app.config.from_object(Config)
    if test_config: app.config.update(test_config)
    app.secret_key=app.config["SECRET_KEY"]
    app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE="Lax",SESSION_COOKIE_SECURE=False)
    logger=get_logger()
    @app.after_request
    def headers(response):
        response.headers.setdefault("X-Content-Type-Options","nosniff")
        response.headers.setdefault("X-Frame-Options","DENY")
        response.headers.setdefault("Referrer-Policy","strict-origin-when-cross-origin")
        response.headers.setdefault("Content-Security-Policy","default-src 'self'; style-src 'self' 'unsafe-inline'")
        return response
    @app.route("/",methods=["GET","POST"])
    def index():
        if request.method=="POST":
            try:
                target=request.form.get("target","").strip()
                findings=assess_url(target); summary=summarize(findings)
                report=generate_pdf(findings)
                logger.info("Local assessment completed; checks=%d",len(findings))
                return render_template("dashboard.html",target=target,findings=findings,summary=summary,report=report)
            except ValueError as e: flash(str(e))
            except Exception as e:
                logger.warning("Assessment failed: %s",type(e).__name__)
                flash("Assessment could not be completed.")
        return render_template("index.html")
    @app.route("/demo-auth",methods=["GET","POST"])
    def demo_auth():
        result=None
        if request.method=="POST":
            user=request.form.get("username",""); pw=request.form.get("password","")
            valid,_=validate_username(user)
            if not valid or not pw or len(pw)>128: result="Input rejected."
            else: result="Synthetic password hash verified: "+str(verify_password(hash_password(pw),pw))
        return render_template("demo_auth.html",result=result)
    return app
app=create_app()
if __name__=="__main__": app.run(host="127.0.0.1",port=5000,debug=False)
