import pytest
from security_scanner import validate_target
def test_localhost_allowed(): assert validate_target("http://127.0.0.1:5000")
@pytest.mark.parametrize("url",["https://example.com","ftp://localhost","bad-url"])
def test_other_targets_rejected(url):
    with pytest.raises(ValueError): validate_target(url)
