from app import create_app
def test_home_and_headers():
    c=create_app({"TESTING":True,"SECRET_KEY":"test-secret"}).test_client()
    r=c.get("/")
    assert r.status_code==200 and r.headers["X-Frame-Options"]=="DENY"
def test_public_target_rejected():
    c=create_app({"TESTING":True,"SECRET_KEY":"test-secret"}).test_client()
    r=c.post("/",data={"target":"https://example.com"},follow_redirects=True)
    assert b"localhost" in r.data
