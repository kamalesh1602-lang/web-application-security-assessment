from authentication_checks import hash_password,verify_password,assess_hash
def test_hash_not_plaintext():
    h=hash_password("Example-Only-Password!")
    assert h!="Example-Only-Password!" and assess_hash(h)["status"]=="PASS"
def test_verify_password():
    h=hash_password("Example-Only-Password!")
    assert verify_password(h,"Example-Only-Password!")
    assert not verify_password(h,"wrong")
