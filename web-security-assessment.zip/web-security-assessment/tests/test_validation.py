from validation_checks import validate_username,validate_text
def test_valid_username(): assert validate_username("student_01")[0]
def test_empty_username(): assert not validate_username(" ")[0]
def test_long_username(): assert not validate_username("x"*33)[0]
def test_wrong_type(): assert not validate_username(None)[0]
def test_text_length(): assert validate_text("ok") and not validate_text("x"*201)
