# Security Methodology

1. Confirm ownership and scope.
2. Start the local app.
3. Run the assessment against localhost.
4. Record exact evidence and status.
5. Treat missing controls as indicators, not proof of exploitability.
6. Apply remediation to the application you administer.
7. Re-run the scanner and tests.
8. Document only verified outcomes.

Severity labels are educational triage guidance; real risk depends on context and impact.
