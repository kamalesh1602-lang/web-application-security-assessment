# Limitations

This is an educational baseline, not a complete penetration-testing product. It does not exploit vulnerabilities, crawl applications, scan ports, audit certificates, or prove that an application is secure. pip-audit requires current advisory data.
