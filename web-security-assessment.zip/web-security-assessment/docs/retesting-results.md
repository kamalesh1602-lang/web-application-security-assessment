# Retesting Results

Run `pytest -v`, save its output, and perform a fresh localhost assessment after remediation.

Do not mark a finding fixed until a new test verifies the expected behavior. Record initial and retest evidence with dates.
