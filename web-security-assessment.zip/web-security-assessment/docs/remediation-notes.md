# Remediation Notes

The demo app adds CSP, X-Frame-Options, X-Content-Type-Options, and Referrer-Policy headers.

For deployment: use HTTPS, enable HSTS only after HTTPS is configured, keep debug disabled, use a strong environment secret, set Secure/HttpOnly/SameSite cookies, validate on the server, and use parameterized SQL queries.

The scanner reports observations, not guaranteed exploitable vulnerabilities.
