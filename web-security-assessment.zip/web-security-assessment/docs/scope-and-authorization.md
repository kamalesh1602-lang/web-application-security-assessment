# Scope and Authorization

Purpose: demonstrate basic defensive checks in a controlled local lab.

Authorized environment: localhost, 127.0.0.1, and ::1 only. The scanner rejects other hosts.

Scope: one non-invasive HTTP GET, response headers, URL scheme indicator, common server-identification headers, and synthetic password hashing.

Out of scope: public systems without written authorization, credential attacks, exploitation, destructive requests, denial-of-service, stealth, persistence, and private-data access.

Authorization template: "I own or have written authorization to assess [local target] during [time window]. I understand the scope and will stop if unexpected impact occurs."

Rules: use synthetic data, keep request volume low, do not follow redirects automatically, and preserve evidence safely.

Privacy: never publish passwords, tokens, cookies, personal data, or secret keys. Review reports before sharing.
